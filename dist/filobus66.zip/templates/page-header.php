<div class="page-header">
  <h3 class="title"><span></span><?php echo roots_title(); ?><span></span></h3>
</div>
