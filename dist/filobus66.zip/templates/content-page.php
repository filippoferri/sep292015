<div class="entry-content">
  <?php the_content(); ?>
</div>
<?php wp_link_pages(array('before' => '<nav class="pagination">', 'after' => '</nav>')); ?>
